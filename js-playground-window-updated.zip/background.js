let playgroundWindowId = null;

chrome.action.onClicked.addListener(async () => {
  // If the playground is already open, focus it instead of opening duplicates.
  if (playgroundWindowId !== null) {
    try {
      const existing = await chrome.windows.get(playgroundWindowId);

      if (existing) {
        await chrome.windows.update(playgroundWindowId, {
          focused: true,
          state: existing.state === "minimized" ? "normal" : existing.state
        });
        return;
      }
    } catch {
      playgroundWindowId = null;
    }
  }

  const win = await chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 900,
    height: 720,
    focused: true
  });

  playgroundWindowId = win.id;
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === playgroundWindowId) {
    playgroundWindowId = null;
  }
});