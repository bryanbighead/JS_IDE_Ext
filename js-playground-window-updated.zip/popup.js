const DEFAULT_CODE = `function dientich(bankinh) {
  var dt_hv_lon = (2 * bankinh) ** 2;
  var dt_hv_nho = 2 * (bankinh ** 2);

  return dt_hv_lon - dt_hv_nho;
}

var r = prompt("Nhap ban kinh:", "1");

console.log(dientich(r));`;

const codeEl = document.getElementById("code");
const outputEl = document.getElementById("output");
const sandboxEl = document.getElementById("sandbox");
const statusEl = document.getElementById("status");
const lineNumbersEl = document.getElementById("lineNumbers");
const lineCountEl = document.getElementById("lineCount");
const autoClearEl = document.getElementById("autoClear");
const highlightEl = document.getElementById("highlight");
const highlightCodeEl = document.getElementById("highlightCode");

function updateLines() {
  const count = codeEl.value.split("\n").length;
  lineNumbersEl.textContent =
    Array.from({ length: count }, (_, i) => i + 1).join("\n");
  lineCountEl.textContent = `${count} ${count === 1 ? "line" : "lines"}`;
}

// ---- Lightweight JS syntax highlighting (VS Code Dark+ inspired) ----

const JS_KEYWORDS =
  "const|let|var|function|return|if|else|for|while|do|switch|case|break|" +
  "continue|default|try|catch|finally|throw|class|extends|super|new|delete|" +
  "typeof|instanceof|in|of|void|yield|async|await|static|import|export|from|" +
  "as|this|null|undefined|true|false|debugger|with|get|set";

const JS_BUILTINS =
  "console|Math|JSON|Array|Object|String|Number|Boolean|Promise|Map|Set|" +
  "WeakMap|WeakSet|Symbol|Error|TypeError|RangeError|SyntaxError|Date|" +
  "RegExp|Function|Proxy|Reflect|globalThis|window|document|parseInt|" +
  "parseFloat|isNaN|isFinite|NaN|Infinity";

const TOKEN_RE = new RegExp(
  "(//[^\\n]*)" + // 1: line comment
  "|(/\\*[\\s\\S]*?\\*/)" + // 2: block comment
  "|(`(?:\\\\.|[^`\\\\])*`)" + // 3: template literal
  "|(\"(?:\\\\.|[^\"\\\\])*\")" + // 4: double-quoted string
  "|('(?:\\\\.|[^'\\\\])*')" + // 5: single-quoted string
  "|(\\b\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?\\b)" + // 6: number
  "|(\\b(?:" + JS_KEYWORDS + ")\\b)" + // 7: keyword
  "|(\\b(?:" + JS_BUILTINS + ")\\b)" + // 8: builtin
  "|([A-Za-z_$][\\w$]*)(?=\\s*\\()", // 9: function call name
  "g"
);

function escapeHtml(str) {
  return str.replace(/[&<>]/g, (ch) => (
    ch === "&" ? "&amp;" : ch === "<" ? "&lt;" : "&gt;"
  ));
}

function highlightCode(code) {
  let result = "";
  let lastIndex = 0;
  let match;

  TOKEN_RE.lastIndex = 0;

  while ((match = TOKEN_RE.exec(code))) {
    if (match.index > lastIndex) {
      result += escapeHtml(code.slice(lastIndex, match.index));
    }

    const text = match[0];
    let cls;

    if (match[1] !== undefined || match[2] !== undefined) cls = "tok-comment";
    else if (match[3] !== undefined) cls = "tok-template";
    else if (match[4] !== undefined || match[5] !== undefined) cls = "tok-string";
    else if (match[6] !== undefined) cls = "tok-number";
    else if (match[7] !== undefined) cls = "tok-keyword";
    else if (match[8] !== undefined) cls = "tok-builtin";
    else cls = "tok-function";

    result += `<span class="${cls}">${escapeHtml(text)}</span>`;
    lastIndex = match.index + text.length;
  }

  result += escapeHtml(code.slice(lastIndex));

  return result;
}

function renderHighlight() {
  // Trailing newline keeps the highlighted layer's last (empty) line the
  // same height as the textarea's, so the two stay pixel-aligned.
  highlightCodeEl.innerHTML = highlightCode(codeEl.value) + "\n";
}

function syncScroll() {
  lineNumbersEl.scrollTop = codeEl.scrollTop;
  highlightEl.scrollTop = codeEl.scrollTop;
  highlightEl.scrollLeft = codeEl.scrollLeft;
}

function formatValue(value) {
  if (typeof value === "string") return value;
  if (value === undefined) return "undefined";
  if (value === null) return "null";
  if (typeof value === "bigint") return `${value}n`;

  if (typeof value === "object") {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  return String(value);
}

function appendOutput(values, type = "log") {
  const line = document.createElement("div");
  line.className = type;
  line.textContent = values.map(formatValue).join(" ");
  outputEl.appendChild(line);
  outputEl.scrollTop = outputEl.scrollHeight;
}

function clearOutput() {
  outputEl.textContent = "";
  statusEl.textContent = "Ready";
  statusEl.classList.remove("error");
}

function runCode() {
  if (autoClearEl.checked) {
    outputEl.textContent = "";
  }

  statusEl.textContent = "Running...";
  statusEl.classList.remove("error");

  sandboxEl.contentWindow.postMessage({
    type: "run",
    code: codeEl.value
  }, "*");
}

function save() {
  chrome.storage.local.set({
    code: codeEl.value,
    autoClear: autoClearEl.checked
  });
}

function load() {
  chrome.storage.local.get(["code", "autoClear"], (data) => {
    codeEl.value = data.code ?? DEFAULT_CODE;
    autoClearEl.checked = data.autoClear ?? true;
    updateLines();
    renderHighlight();
  });
}

window.addEventListener("message", (event) => {
  const data = event.data;

  if (!data || !data.type) return;

  if (data.type === "clear") {
    outputEl.textContent = "";
    return;
  }

  if (["log", "info", "warn", "error"].includes(data.type)) {
    appendOutput(data.values || [], data.type);
  }

  if (data.type === "done") {
    statusEl.textContent = data.failed ? "Error" : "Success";

    if (data.failed) {
      statusEl.classList.add("error");
    }
  }
});

codeEl.addEventListener("input", () => {
  updateLines();
  renderHighlight();
  save();
});

codeEl.addEventListener("scroll", syncScroll);

codeEl.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
    event.preventDefault();
    runCode();
  }

  if (event.key === "Tab") {
    event.preventDefault();

    const start = codeEl.selectionStart;
    const end = codeEl.selectionEnd;

    codeEl.value =
      codeEl.value.slice(0, start) +
      "  " +
      codeEl.value.slice(end);

    codeEl.selectionStart = codeEl.selectionEnd = start + 2;

    updateLines();
    renderHighlight();
    save();
  }
});

document.getElementById("runBtn").addEventListener("click", runCode);

document.getElementById("clearBtn").addEventListener("click", clearOutput);

document.getElementById("resetBtn").addEventListener("click", () => {
  codeEl.value = DEFAULT_CODE;
  save();
  updateLines();
  renderHighlight();
  clearOutput();
});

autoClearEl.addEventListener("change", save);

document.getElementById("copyBtn").addEventListener("click", async () => {
  await navigator.clipboard.writeText(outputEl.textContent);

  const button = document.getElementById("copyBtn");
  const oldText = button.textContent;

  button.textContent = "Copied!";

  setTimeout(() => {
    button.textContent = oldText;
  }, 900);
});

load();