# JS Mini Playground — Window Version

A Chrome Extension JavaScript playground that opens as a separate, movable and resizable window.

## Features

- Separate Chrome popup window instead of the fixed extension dropdown
- Drag the window anywhere
- Resize the window
- JavaScript editor
- Run with `Ctrl + Enter`
- `console.log`, `console.info`, `console.warn`, `console.error`
- Clear / Reset
- Copy output
- Line numbers
- Tab inserts two spaces
- Automatically saves code with Chrome Storage
- JavaScript runs in an extension sandbox

## Install

1. Extract the ZIP.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Enable Developer mode.
5. Click **Load unpacked**.
6. Select the `js-playground-window` folder.
7. Click the extension icon.

The extension icon now opens a separate window that you can move and resize.

## Architecture

```text
Extension icon
      |
      v
background.js
      |
      v
chrome.windows.create()
      |
      v
popup.html
      |
      | postMessage()
      v
sandbox.html
      |
      v
JavaScript execution
      |
      | postMessage()
      v
popup.js
      |
      v
Console Output
```

The extension page does not directly use `eval()` / `new Function()`. User code is executed in the declared sandbox page.

## Important

This is a learning playground. Do not give a production extension sensitive permissions and then execute untrusted code without a proper security design.
