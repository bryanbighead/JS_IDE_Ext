# JS Mini Playground

Chrome Extension để luyện JavaScript Fundamental.

## Cấu trúc

- `manifest.json`: cấu hình extension
- `popup.html`: giao diện
- `popup.css`: giao diện
- `popup.js`: xử lý editor, Run và output
- `sandbox.html`: môi trường chạy JavaScript người dùng nhập

## Cài đặt

1. Giải nén ZIP.
2. Mở Chrome.
3. Vào `chrome://extensions`.
4. Bật Developer mode.
5. Chọn Load unpacked.
6. Chọn thư mục `js-playground-v1`.

## Kiến trúc

Popup không trực tiếp dùng `eval()` / `new Function()`.

Code được gửi bằng `postMessage()` sang `sandbox.html`, sau đó sandbox thực thi code và gửi kết quả console ngược lại.

## Lưu ý

Đây là playground học tập. Không nên chạy code không tin cậy trong extension thật có quyền truy cập dữ liệu nhạy cảm.
