const DEFAULT_CODE = `function dientich(bankinh) {
  var dt_hv_lon = (2 * bankinh) ** 2;
  var dt_hv_nho = 2 * (bankinh ** 2);

  return dt_hv_lon - dt_hv_nho;
}

var r = prompt("Nhap ban kinh:", "1");

console.log(dientich(r));`;

const codeEl = document.getElementById("code");
const outputEl = document.getElementById("output");
const sandboxEl = document.getElementById("sandbox");
const statusEl = document.getElementById("status");
const lineNumbersEl = document.getElementById("lineNumbers");
const lineCountEl = document.getElementById("lineCount");
const autoClearEl = document.getElementById("autoClear");

function updateLines() {
  const count = codeEl.value.split("\n").length;
  lineNumbersEl.textContent =
    Array.from({ length: count }, (_, i) => i + 1).join("\n");
  lineCountEl.textContent = `${count} ${count === 1 ? "line" : "lines"}`;
}

function formatValue(value) {
  if (typeof value === "string") return value;
  if (value === undefined) return "undefined";
  if (value === null) return "null";
  if (typeof value === "bigint") return `${value}n`;

  if (typeof value === "object") {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  return String(value);
}

function appendOutput(values, type = "log") {
  const line = document.createElement("div");
  line.className = type;
  line.textContent = values.map(formatValue).join(" ");
  outputEl.appendChild(line);
  outputEl.scrollTop = outputEl.scrollHeight;
}

function clearOutput() {
  outputEl.textContent = "";
  statusEl.textContent = "Ready";
  statusEl.classList.remove("error");
}

function runCode() {
  if (autoClearEl.checked) {
    outputEl.textContent = "";
  }

  statusEl.textContent = "Running...";
  statusEl.classList.remove("error");

  sandboxEl.contentWindow.postMessage({
    type: "run",
    code: codeEl.value
  }, "*");
}

function save() {
  chrome.storage.local.set({
    code: codeEl.value,
    autoClear: autoClearEl.checked
  });
}

function load() {
  chrome.storage.local.get(["code", "autoClear"], (data) => {
    codeEl.value = data.code ?? DEFAULT_CODE;
    autoClearEl.checked = data.autoClear ?? true;
    updateLines();
  });
}

window.addEventListener("message", (event) => {
  const data = event.data;

  if (!data || !data.type) return;

  if (data.type === "clear") {
    outputEl.textContent = "";
    return;
  }

  if (["log", "info", "warn", "error"].includes(data.type)) {
    appendOutput(data.values || [], data.type);
  }

  if (data.type === "done") {
    statusEl.textContent = data.failed ? "Error" : "Success";

    if (data.failed) {
      statusEl.classList.add("error");
    }
  }
});

codeEl.addEventListener("input", () => {
  updateLines();
  save();
});

codeEl.addEventListener("scroll", () => {
  lineNumbersEl.scrollTop = codeEl.scrollTop;
});

codeEl.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
    event.preventDefault();
    runCode();
  }

  if (event.key === "Tab") {
    event.preventDefault();

    const start = codeEl.selectionStart;
    const end = codeEl.selectionEnd;

    codeEl.value =
      codeEl.value.slice(0, start) +
      "  " +
      codeEl.value.slice(end);

    codeEl.selectionStart = codeEl.selectionEnd = start + 2;

    updateLines();
    save();
  }
});

document.getElementById("runBtn").addEventListener("click", runCode);

document.getElementById("clearBtn").addEventListener("click", clearOutput);

document.getElementById("resetBtn").addEventListener("click", () => {
  codeEl.value = DEFAULT_CODE;
  save();
  updateLines();
  clearOutput();
});

autoClearEl.addEventListener("change", save);

document.getElementById("copyBtn").addEventListener("click", async () => {
  await navigator.clipboard.writeText(outputEl.textContent);

  const button = document.getElementById("copyBtn");
  const oldText = button.textContent;

  button.textContent = "Copied!";

  setTimeout(() => {
    button.textContent = oldText;
  }, 900);
});

load();